-- Generado por Oracle SQL Developer Data Modeler 24.3.1.351.0831
--   en:        2025-09-15 20:40:01 CLST
--   sitio:      Oracle Database 11g
--   tipo:      Oracle Database 11g



-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE AFP 
    ( 
     id_afp   NUMBER  NOT NULL , 
     nombre_a VARCHAR2 (25 CHAR)  NOT NULL 
    ) 
;

ALTER TABLE AFP 
    ADD CONSTRAINT PK_AFP PRIMARY KEY ( id_afp ) ;

ALTER TABLE AFP 
    ADD CONSTRAINT AFP_nombre_a_UN UNIQUE ( nombre_a ) ;

CREATE TABLE ATENCION_MEDICA 
    ( 
     id_atencion                    NUMBER  NOT NULL , 
     fecha_a                        DATE  NOT NULL , 
     hora_a                         DATE  NOT NULL , 
     examenes_solicitados           VARCHAR2 (100)  NOT NULL , 
     MEDICO_id_medico               NUMBER  NOT NULL , 
     MEDICO_INSTITUCION_SALUD_id_is NUMBER  NOT NULL , 
     PACIENTE_id_paciente           NUMBER  NOT NULL , 
     PAGO_ATENCION_id_pago          NUMBER  NOT NULL , 
     DIAGNOSTICO_id_diagnostico     NUMBER  NOT NULL 
    ) 
;
CREATE UNIQUE INDEX ATENCION_MEDICA__IDX ON ATENCION_MEDICA 
    ( 
     PAGO_ATENCION_id_pago ASC 
    ) 
;

ALTER TABLE ATENCION_MEDICA 
    ADD CONSTRAINT PK_ATENCION_MEDICA PRIMARY KEY ( id_atencion, DIAGNOSTICO_id_diagnostico ) ;


--  ERROR: UK name length exceeds maximum allowed length(30) 
ALTER TABLE ATENCION_MEDICA 
    ADD CONSTRAINT ATENCION_MEDICA_examenes_solicitados_UN UNIQUE ( examenes_solicitados ) ;

CREATE TABLE COMUNA 
    ( 
     id_comuna        NUMBER  NOT NULL , 
     nombre           VARCHAR2 (50 CHAR)  NOT NULL , 
     REGION_REGION_ID NUMBER  NOT NULL , 
     nombre1          VARCHAR2 (100 CHAR)  NOT NULL 
    ) 
;

ALTER TABLE COMUNA 
    ADD CONSTRAINT PK_COMUNA PRIMARY KEY ( id_comuna ) ;

ALTER TABLE COMUNA 
    ADD CONSTRAINT COMUNA_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE DIAGNOSTICO 
    ( 
     id_diagnostico NUMBER  NOT NULL , 
     nombre         VARCHAR2 (25 CHAR)  NOT NULL 
    ) 
;

ALTER TABLE DIAGNOSTICO 
    ADD CONSTRAINT PK_DIAGNOSTICO PRIMARY KEY ( id_diagnostico ) ;

ALTER TABLE DIAGNOSTICO 
    ADD CONSTRAINT DIAGNOSTICO_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE ESPECIALIDAD 
    ( 
     id_especialidad NUMBER  NOT NULL , 
     nombre_e        VARCHAR2 (25 CHAR)  NOT NULL 
    ) 
;

ALTER TABLE ESPECIALIDAD 
    ADD CONSTRAINT PK_ESPECIALIDAD PRIMARY KEY ( id_especialidad ) ;

ALTER TABLE ESPECIALIDAD 
    ADD CONSTRAINT ESPECIALIDAD_nombre_e_UN UNIQUE ( nombre_e ) ;

CREATE TABLE EXAMENES_LABO 
    ( 
     codigo          NUMBER  NOT NULL , 
     nombre          VARCHAR2 (25 CHAR)  NOT NULL , 
     tipo_muestra    VARCHAR2 (25 CHAR)  NOT NULL , 
     condicion_prepa VARCHAR2 (25)  NOT NULL 
    ) 
;

ALTER TABLE EXAMENES_LABO 
    ADD CONSTRAINT PK_EXAMENES_LABO PRIMARY KEY ( codigo ) ;

ALTER TABLE EXAMENES_LABO 
    ADD CONSTRAINT EXAMENES_LABO_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE EXAMENES_SOLICITADOS 
    ( 
     examen_1                                   VARCHAR2 (25 CHAR)  NOT NULL , 
     examen_2                                   VARCHAR2 (25 CHAR) , 
     examen_3                                   VARCHAR2 (25 CHAR) , 
     ATENCION_MEDICA_id_atencion                NUMBER  NOT NULL , 
--  ERROR: Column name length exceeds maximum allowed length(30) 
     ATENCION_MEDICA_DIAGNOSTICO_id_diagnostico NUMBER  NOT NULL 
    ) 
;

CREATE TABLE GENERO 
    ( 
     id_genero NUMBER  NOT NULL , 
     nombre    VARCHAR2 (10 CHAR)  NOT NULL 
    ) 
;

ALTER TABLE GENERO 
    ADD CONSTRAINT PK_GENERO PRIMARY KEY ( id_genero ) ;

ALTER TABLE GENERO 
    ADD CONSTRAINT GENERO_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE INSTITUCION_SALUD 
    ( 
     id_is     NUMBER  NOT NULL , 
     nombre_is VARCHAR2 (25 CHAR)  NOT NULL 
    ) 
;

ALTER TABLE INSTITUCION_SALUD 
    ADD CONSTRAINT PK_INSTITUCION_SALUD PRIMARY KEY ( id_is ) ;

ALTER TABLE INSTITUCION_SALUD 
    ADD CONSTRAINT INSTITUCION_SALUD_nombre_is_UN UNIQUE ( nombre_is ) ;

CREATE TABLE MEDICO 
    ( 
     id_medico                      NUMBER  NOT NULL , 
     rut_medico                     VARCHAR2 (10)  NOT NULL , 
     nombre_c                       VARCHAR2 (100 CHAR)  NOT NULL , 
     fecha_i                        DATE  NOT NULL , 
     AFP_id_afp                     NUMBER  NOT NULL , 
     INSTITUCION_SALUD_id_is        NUMBER  NOT NULL , 
     ESPECIALIDAD_id_especialidad   NUMBER  NOT NULL , 
     MEDICO_id_medico               NUMBER , 
     MEDICO_INSTITUCION_SALUD_id_is NUMBER 
    ) 
;
CREATE UNIQUE INDEX MEDICO__IDX ON MEDICO 
    ( 
     MEDICO_id_medico ASC , 
     MEDICO_INSTITUCION_SALUD_id_is ASC 
    ) 
;

ALTER TABLE MEDICO 
    ADD CONSTRAINT PK_MEDICO PRIMARY KEY ( id_medico, INSTITUCION_SALUD_id_is ) ;

ALTER TABLE MEDICO 
    ADD CONSTRAINT MEDICO_rut_medico_UN UNIQUE ( rut_medico ) ;

CREATE TABLE MODALIDAD 
    ( 
     id_modalidad NUMBER  NOT NULL , 
     nombre_m     VARCHAR2 (10)  NOT NULL 
    ) 
;

ALTER TABLE MODALIDAD 
    ADD CONSTRAINT PK_MODALIDAD PRIMARY KEY ( id_modalidad ) ;

ALTER TABLE MODALIDAD 
    ADD CONSTRAINT MODALIDAD_nombre_m_UN UNIQUE ( nombre_m ) ;

CREATE TABLE PACIENTE 
    ( 
     id_paciente      NUMBER  NOT NULL , 
     rut_paciente     VARCHAR2 (10 CHAR)  NOT NULL , 
     nombre_p         VARCHAR2 (100 CHAR)  NOT NULL , 
     fecha_n          DATE  NOT NULL , 
     direccion        VARCHAR2 (100 CHAR)  NOT NULL , 
     COMUNA_id_comuna NUMBER  NOT NULL , 
     GENERO_id_genero NUMBER  NOT NULL , 
     tipo_paciente    VARCHAR2 (25)  NOT NULL 
    ) 
;

ALTER TABLE PACIENTE 
    ADD CONSTRAINT PACIENTE_PK PRIMARY KEY ( id_paciente ) ;

ALTER TABLE PACIENTE 
    ADD CONSTRAINT PACIENTE_rut_paciente_UN UNIQUE ( rut_paciente ) ;

CREATE TABLE PAGO_ATENCION 
    ( 
     monto_pagado NUMBER  NOT NULL , 
     fecha_pago   DATE  NOT NULL , 
     id_pago      NUMBER  NOT NULL , 
     folio        NUMBER  NOT NULL 
    ) 
;

ALTER TABLE PAGO_ATENCION 
    ADD CONSTRAINT CK_PAGO_ATENCION_MONTO_PAGADO 
    CHECK (monto_pagado > 0) 
;

ALTER TABLE PAGO_ATENCION 
    ADD CONSTRAINT PK_PAGO_ATENCION PRIMARY KEY ( id_pago ) ;

ALTER TABLE PAGO_ATENCION 
    ADD CONSTRAINT PAGO_ATENCION_folio_UN UNIQUE ( folio ) ;

CREATE TABLE REGION 
    ( 
     id_region NUMBER , 
     nombre    VARCHAR2 (100 CHAR)  NOT NULL , 
     REGION_ID NUMBER  NOT NULL 
    ) 
;

ALTER TABLE REGION 
    ADD CONSTRAINT PK_REGION PRIMARY KEY ( REGION_ID ) ;

ALTER TABLE REGION 
    ADD CONSTRAINT REGION_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE TI_M_AM 
    ( 
     ATENCION_MEDICA_id_atencion    NUMBER  NOT NULL , 
     ATENCION_MEDICA_id_diagnostico NUMBER  NOT NULL , 
     MODALIDAD_id_modalidad         NUMBER  NOT NULL 
    ) 
;

ALTER TABLE TI_M_AM 
    ADD CONSTRAINT PK_Relation_2 PRIMARY KEY ( ATENCION_MEDICA_id_atencion, ATENCION_MEDICA_id_diagnostico, MODALIDAD_id_modalidad ) ;

CREATE TABLE TI_ME_EX_LB 
    ( 
     EXAMENES_LABO_codigo NUMBER  NOT NULL , 
     MEDICO_id_medico     NUMBER  NOT NULL , 
     MEDICO_id_is         NUMBER  NOT NULL 
    ) 
;

ALTER TABLE TI_ME_EX_LB 
    ADD CONSTRAINT PK_Relation_14 PRIMARY KEY ( EXAMENES_LABO_codigo, MEDICO_id_medico, MEDICO_id_is ) ;

CREATE TABLE TI_TA_AM 
    ( 
     ATENCION_MEDICA_id_atencion    NUMBER  NOT NULL , 
     ATENCION_MEDICA_id_diagnostico NUMBER  NOT NULL , 
     TIPO_ATENCION_id_tipo          NUMBER  NOT NULL 
    ) 
;

ALTER TABLE TI_TA_AM 
    ADD CONSTRAINT PK_Relation_1 PRIMARY KEY ( ATENCION_MEDICA_id_atencion, ATENCION_MEDICA_id_diagnostico, TIPO_ATENCION_id_tipo ) ;

CREATE TABLE TIPO_ATENCION 
    ( 
     id_tipo  NUMBER  NOT NULL , 
     nombre_a VARCHAR2 (20)  NOT NULL 
    ) 
;

ALTER TABLE TIPO_ATENCION 
    ADD CONSTRAINT PK_TIPO_ATENCION PRIMARY KEY ( id_tipo ) ;

ALTER TABLE TIPO_ATENCION 
    ADD CONSTRAINT TIPO_ATENCION_nombre_a_UN UNIQUE ( nombre_a ) ;

CREATE TABLE TIPO_PAGO 
    ( 
     metodo_pago           VARCHAR2 (20 CHAR)  NOT NULL , 
     PAGO_ATENCION_id_pago NUMBER  NOT NULL 
    ) 
;

ALTER TABLE TIPO_PAGO 
    ADD CONSTRAINT TIPO_PAGO_metodo_pago_UN UNIQUE ( metodo_pago ) ;

ALTER TABLE ATENCION_MEDICA 
    ADD CONSTRAINT ATENCION_MEDICA_DIAGNOSTICO_FK FOREIGN KEY 
    ( 
     DIAGNOSTICO_id_diagnostico
    ) 
    REFERENCES DIAGNOSTICO 
    ( 
     id_diagnostico
    ) 
;

ALTER TABLE ATENCION_MEDICA 
    ADD CONSTRAINT ATENCION_MEDICA_MEDICO_FK FOREIGN KEY 
    ( 
     MEDICO_id_medico,
     MEDICO_INSTITUCION_SALUD_id_is
    ) 
    REFERENCES MEDICO 
    ( 
     id_medico,
     INSTITUCION_SALUD_id_is
    ) 
;

ALTER TABLE ATENCION_MEDICA 
    ADD CONSTRAINT ATENCION_MEDICA_PACIENTE_FK FOREIGN KEY 
    ( 
     PACIENTE_id_paciente
    ) 
    REFERENCES PACIENTE 
    ( 
     id_paciente
    ) 
;

--  ERROR: FK name length exceeds maximum allowed length(30) 
ALTER TABLE ATENCION_MEDICA 
    ADD CONSTRAINT ATENCION_MEDICA_PAGO_ATENCION_FK FOREIGN KEY 
    ( 
     PAGO_ATENCION_id_pago
    ) 
    REFERENCES PAGO_ATENCION 
    ( 
     id_pago
    ) 
;

ALTER TABLE COMUNA 
    ADD CONSTRAINT COMUNA_REGION_FK FOREIGN KEY 
    ( 
     nombre1
    ) 
    REFERENCES REGION 
    ( 
     REGION_ID
    ) 
;

--  ERROR: FK name length exceeds maximum allowed length(30) 
ALTER TABLE EXAMENES_SOLICITADOS 
    ADD CONSTRAINT EXAMENES_SOLICITADOS_ATENCION_MEDICA_FK FOREIGN KEY 
    ( 
     ATENCION_MEDICA_id_atencion,
     ATENCION_MEDICA_DIAGNOSTICO_id_diagnostico
    ) 
    REFERENCES ATENCION_MEDICA 
    ( 
     id_atencion,
     DIAGNOSTICO_id_diagnostico
    ) 
;

ALTER TABLE TI_TA_AM 
    ADD CONSTRAINT FK_Relation_1_ATENCION_MEDICA FOREIGN KEY 
    ( 
     ATENCION_MEDICA_id_atencion,
     ATENCION_MEDICA_id_diagnostico
    ) 
    REFERENCES ATENCION_MEDICA 
    ( 
     id_atencion,
     DIAGNOSTICO_id_diagnostico
    ) 
;

ALTER TABLE TI_TA_AM 
    ADD CONSTRAINT FK_Relation_1_TIPO_ATENCION FOREIGN KEY 
    ( 
     TIPO_ATENCION_id_tipo
    ) 
    REFERENCES TIPO_ATENCION 
    ( 
     id_tipo
    ) 
;

ALTER TABLE TI_ME_EX_LB 
    ADD CONSTRAINT FK_Relation_14_EXAMENES_LABO FOREIGN KEY 
    ( 
     EXAMENES_LABO_codigo
    ) 
    REFERENCES EXAMENES_LABO 
    ( 
     codigo
    ) 
;

ALTER TABLE TI_ME_EX_LB 
    ADD CONSTRAINT FK_Relation_14_MEDICO FOREIGN KEY 
    ( 
     MEDICO_id_medico,
     MEDICO_id_is
    ) 
    REFERENCES MEDICO 
    ( 
     id_medico,
     INSTITUCION_SALUD_id_is
    ) 
;

ALTER TABLE TI_M_AM 
    ADD CONSTRAINT FK_Relation_2_ATENCION_MEDICA FOREIGN KEY 
    ( 
     ATENCION_MEDICA_id_atencion,
     ATENCION_MEDICA_id_diagnostico
    ) 
    REFERENCES ATENCION_MEDICA 
    ( 
     id_atencion,
     DIAGNOSTICO_id_diagnostico
    ) 
;

ALTER TABLE TI_M_AM 
    ADD CONSTRAINT FK_Relation_2_MODALIDAD FOREIGN KEY 
    ( 
     MODALIDAD_id_modalidad
    ) 
    REFERENCES MODALIDAD 
    ( 
     id_modalidad
    ) 
;

ALTER TABLE MEDICO 
    ADD CONSTRAINT MEDICO_AFP_FK FOREIGN KEY 
    ( 
     AFP_id_afp
    ) 
    REFERENCES AFP 
    ( 
     id_afp
    ) 
;

ALTER TABLE MEDICO 
    ADD CONSTRAINT MEDICO_ESPECIALIDAD_FK FOREIGN KEY 
    ( 
     ESPECIALIDAD_id_especialidad
    ) 
    REFERENCES ESPECIALIDAD 
    ( 
     id_especialidad
    ) 
;

ALTER TABLE MEDICO 
    ADD CONSTRAINT MEDICO_INSTITUCION_SALUD_FK FOREIGN KEY 
    ( 
     INSTITUCION_SALUD_id_is
    ) 
    REFERENCES INSTITUCION_SALUD 
    ( 
     id_is
    ) 
;

ALTER TABLE MEDICO 
    ADD CONSTRAINT MEDICO_MEDICO_FK FOREIGN KEY 
    ( 
     MEDICO_id_medico,
     MEDICO_INSTITUCION_SALUD_id_is
    ) 
    REFERENCES MEDICO 
    ( 
     id_medico,
     INSTITUCION_SALUD_id_is
    ) 
;

ALTER TABLE PACIENTE 
    ADD CONSTRAINT PACIENTE_COMUNA_FK FOREIGN KEY 
    ( 
     COMUNA_id_comuna
    ) 
    REFERENCES COMUNA 
    ( 
     id_comuna
    ) 
;

ALTER TABLE PACIENTE 
    ADD CONSTRAINT PACIENTE_GENERO_FK FOREIGN KEY 
    ( 
     GENERO_id_genero
    ) 
    REFERENCES GENERO 
    ( 
     id_genero
    ) 
;

ALTER TABLE TIPO_PAGO 
    ADD CONSTRAINT TIPO_PAGO_PAGO_ATENCION_FK FOREIGN KEY 
    ( 
     PAGO_ATENCION_id_pago
    ) 
    REFERENCES PAGO_ATENCION 
    ( 
     id_pago
    ) 
;

CREATE SEQUENCE REGION_REGION_ID_SEQ 
START WITH 1 
    NOCACHE 
    ORDER ;

CREATE OR REPLACE TRIGGER REGION_REGION_ID_TRG 
BEFORE INSERT ON REGION 
FOR EACH ROW 
WHEN (NEW.REGION_ID IS NULL) 
BEGIN 
    :NEW.REGION_ID := REGION_REGION_ID_SEQ.NEXTVAL; 
END;
/



-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            19
-- CREATE INDEX                             2
-- ALTER TABLE                             52
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           1
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          1
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   4
-- WARNINGS                                 0

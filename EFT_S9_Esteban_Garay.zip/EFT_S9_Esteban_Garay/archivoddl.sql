-- Generado por Oracle SQL Developer Data Modeler 24.3.1.351.0831
--   en:        2025-10-11 14:14:09 CLST
--   sitio:      Oracle Database 11g
--   tipo:      Oracle Database 11g



-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE AFP 
    ( 
     id_afp NUMBER  NOT NULL , 
     nombre VARCHAR2 (50)  NOT NULL 
    ) 
;

ALTER TABLE AFP 
    ADD CONSTRAINT PK_AFP PRIMARY KEY ( id_afp ) ;

ALTER TABLE AFP 
    ADD CONSTRAINT AFP_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE CATEGORIA 
    ( 
     id_categoria NUMBER  NOT NULL , 
     nombre       VARCHAR2 (10)  NOT NULL 
    ) 
;

ALTER TABLE CATEGORIA 
    ADD CONSTRAINT PK_CATEGORIA PRIMARY KEY ( id_categoria ) ;

ALTER TABLE CATEGORIA 
    ADD CONSTRAINT CATEGORIA_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE CERTIFICACION 
    ( 
     id_certificacion NUMBER  NOT NULL , 
     presencia        VARCHAR2 (2)  NOT NULL 
    ) 
;

ALTER TABLE CERTIFICACION 
    ADD CONSTRAINT PK_CERTIFICACION PRIMARY KEY ( id_certificacion ) ;

CREATE TABLE COMUNA 
    ( 
     cod_comuna        NUMBER  NOT NULL , 
     nombre            VARCHAR2 (100)  NOT NULL , 
     REGION_cod_region NUMBER 
    ) 
;

ALTER TABLE COMUNA 
    ADD CONSTRAINT PK_COMUNA PRIMARY KEY ( cod_comuna ) ;

ALTER TABLE COMUNA 
    ADD CONSTRAINT COMUNA_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE EMPLEADO 
    ( 
     cod_empleado            NUMBER  NOT NULL , 
     rut                     NVARCHAR2 (10)  NOT NULL , 
     nombres                 VARCHAR2 
--  ERROR: VARCHAR2 size not specified 
                     NOT NULL , 
     a_paterno               VARCHAR2 
--  ERROR: VARCHAR2 size not specified 
                     NOT NULL , 
     a_materno               VARCHAR2 
--  ERROR: VARCHAR2 size not specified 
                     NOT NULL , 
     f_contrata              DATE  NOT NULL , 
     sueldo_base             NUMBER  NOT NULL , 
     area_respon             VARCHAR2 (30) , 
     maximo_operarios        NUMBER , 
     PLANTA_cod_planta       NUMBER  NOT NULL , 
     AFP_id_afp              NUMBER , 
     SALUD_id_salud          NUMBER , 
     MAQUINA_id_maquina      NUMBER , 
     TURNO_id_turno          NUMBER  NOT NULL , 
     EMPLEADO_cod_empleado   NUMBER , 
     EMPLEADO_cod_planta     NUMBER , 
     EMPLEADO_id_turno       NUMBER , 
     ESTADO_ACTIVO_id_estado NUMBER  NOT NULL , 
     EMPLEADO_id_estado      NUMBER 
    ) 
;

ALTER TABLE EMPLEADO 
    ADD 
    CHECK (sueldo_base > 0) 
;
CREATE UNIQUE INDEX EMPLEADO__IDX ON EMPLEADO 
    ( 
     EMPLEADO_cod_empleado ASC , 
     EMPLEADO_cod_planta ASC , 
     EMPLEADO_id_turno ASC , 
     EMPLEADO_id_estado ASC 
    ) 
;

ALTER TABLE EMPLEADO 
    ADD CONSTRAINT PK_EMPLEADO PRIMARY KEY ( cod_empleado, PLANTA_cod_planta, TURNO_id_turno, ESTADO_ACTIVO_id_estado ) ;

ALTER TABLE EMPLEADO 
    ADD CONSTRAINT EMPLEADO_rut_UN UNIQUE ( rut ) ;

CREATE TABLE ESPECIALIDAD 
    ( 
     id_especialidad NUMBER  NOT NULL , 
     nombre_e        VARCHAR2 (20)  NOT NULL 
    ) 
;

ALTER TABLE ESPECIALIDAD 
    ADD CONSTRAINT PK_ESPECIALIDAD PRIMARY KEY ( id_especialidad ) ;

ALTER TABLE ESPECIALIDAD 
    ADD CONSTRAINT ESPECIALIDAD_nombre_e_UN UNIQUE ( nombre_e ) ;

CREATE TABLE ESTADO_ACTIVO 
    ( 
     id_estado   NUMBER  NOT NULL , 
     tipo_estado CHAR (2)  NOT NULL 
    ) 
;

ALTER TABLE ESTADO_ACTIVO 
    ADD CONSTRAINT PK_ESTADO_ACTIVO PRIMARY KEY ( id_estado ) ;

ALTER TABLE ESTADO_ACTIVO 
    ADD CONSTRAINT ESTADO_ACTIVO_tipo_estado_UN UNIQUE ( tipo_estado ) ;

CREATE TABLE ESTADO_MAQUI 
    ( 
     id_estado   NUMBER  NOT NULL , 
     tipo_estado CHAR (1)  NOT NULL 
    ) 
;

ALTER TABLE ESTADO_MAQUI 
    ADD CONSTRAINT PK_ESTADO_MAQUI PRIMARY KEY ( id_estado ) ;

ALTER TABLE ESTADO_MAQUI 
    ADD CONSTRAINT ESTADO_MAQUI_tipo_estado_UN UNIQUE ( tipo_estado ) ;

CREATE TABLE ESTADO_MAQUIv2 
    ( 
     ESTADO_MAQUI_id_estado NUMBER  NOT NULL , 
     MAQUINA_id_maquina     NUMBER  NOT NULL 
    ) 
;

ALTER TABLE ESTADO_MAQUIv2 
    ADD CONSTRAINT PK_ESTADO_MAQUIv1 PRIMARY KEY ( ESTADO_MAQUI_id_estado, MAQUINA_id_maquina ) ;

CREATE TABLE INTERMEDIA_TURNO 
    ( 
     TURNO_id_turno     NUMBER  NOT NULL , 
     TIPO_TURNO_id_tipo NUMBER  NOT NULL 
    ) 
;

ALTER TABLE INTERMEDIA_TURNO 
    ADD CONSTRAINT Relation_9_PK PRIMARY KEY ( TURNO_id_turno, TIPO_TURNO_id_tipo ) ;

CREATE TABLE MAQUINA 
    ( 
     id_maquina   NUMBER  NOT NULL , 
     numero       NUMBER  NOT NULL , 
     tipo_maquina VARCHAR2 
--  ERROR: VARCHAR2 size not specified 
                     NOT NULL 
    ) 
;

ALTER TABLE MAQUINA 
    ADD CONSTRAINT CK_MAQUINA_N 
    CHECK (numero > 0) 
;

ALTER TABLE MAQUINA 
    ADD CONSTRAINT PK_MAQUINA PRIMARY KEY ( id_maquina ) ;

CREATE TABLE OPERARIO 
    ( 
     cod_empleado                   NUMBER  NOT NULL , 
     horas_turno                    NUMBER  NOT NULL , 
     CATEGORIA_id_categoria         NUMBER  NOT NULL , 
     CERTIFICACION_id_certificacion NUMBER  NOT NULL , 
     cod_planta                     NUMBER  NOT NULL , 
     id_turno                       NUMBER  NOT NULL , 
     id_estado                      NUMBER  NOT NULL 
    ) 
;

ALTER TABLE OPERARIO 
    ADD 
    CHECK (horas_turno > 0) 
;

ALTER TABLE OPERARIO 
    ADD CONSTRAINT PK_OPERARIO PRIMARY KEY ( cod_empleado, cod_planta, id_turno, id_estado ) ;

CREATE TABLE PLANTA 
    ( 
     cod_planta        NUMBER  NOT NULL , 
     nombre            VARCHAR2 (100)  NOT NULL , 
     direccion         VARCHAR2 (200)  NOT NULL , 
     COMUNA_cod_comuna NUMBER 
    ) 
;

ALTER TABLE PLANTA 
    ADD CONSTRAINT PK_PLANTA PRIMARY KEY ( cod_planta ) ;

ALTER TABLE PLANTA 
    ADD CONSTRAINT PLANTA_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE REGION 
    ( 
     cod_region NUMBER  NOT NULL , 
     nombre     VARCHAR2 (100)  NOT NULL 
    ) 
;

ALTER TABLE REGION 
    ADD CONSTRAINT PK_REGION PRIMARY KEY ( cod_region ) ;

ALTER TABLE REGION 
    ADD CONSTRAINT REGION_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE SALUD 
    ( 
     id_salud NUMBER  NOT NULL , 
     nombre   VARCHAR2 (50)  NOT NULL 
    ) 
;

ALTER TABLE SALUD 
    ADD CONSTRAINT PK_SALUD PRIMARY KEY ( id_salud ) ;

ALTER TABLE SALUD 
    ADD CONSTRAINT SALUD_nombre_UN UNIQUE ( nombre ) ;

CREATE TABLE TECNICOS_MANT 
    ( 
     cod_empleado                 NUMBER  NOT NULL , 
     certficacion                 VARCHAR2 
--  ERROR: VARCHAR2 size not specified 
                     NOT NULL , 
     tiempo_respuesta             DATE  NOT NULL , 
     ESPECIALIDAD_id_especialidad NUMBER  NOT NULL , 
     cod_planta                   NUMBER  NOT NULL , 
     id_turno                     NUMBER  NOT NULL , 
     id_estado                    NUMBER  NOT NULL 
    ) 
;

ALTER TABLE TECNICOS_MANT 
    ADD CONSTRAINT PK_TECNICOS_MANT PRIMARY KEY ( cod_empleado, cod_planta, id_turno, id_estado ) ;

CREATE TABLE TIPO_TURNO 
    ( 
     id_tipo NUMBER  NOT NULL , 
     tipo    VARCHAR2 (10)  NOT NULL 
    ) 
;

ALTER TABLE TIPO_TURNO 
    ADD CONSTRAINT PK_TIPO_TURNO PRIMARY KEY ( id_tipo ) ;

ALTER TABLE TIPO_TURNO 
    ADD CONSTRAINT TIPO_TURNO_tipo_UN UNIQUE ( tipo ) ;

CREATE TABLE TURNO 
    ( 
     id_turno    NUMBER  NOT NULL , 
     hora_inicio DATE  NOT NULL , 
     hora_t      DATE  NOT NULL , 
     fecha       DATE  NOT NULL 
    ) 
;

ALTER TABLE TURNO 
    ADD CONSTRAINT PK_TURNO PRIMARY KEY ( id_turno ) ;

ALTER TABLE EMPLEADO 
    ADD CONSTRAINT EMPLEADO_SALUD_FK FOREIGN KEY 
    ( 
     SALUD_id_salud
    ) 
    REFERENCES SALUD 
    ( 
     id_salud
    ) 
;

ALTER TABLE EMPLEADO 
    ADD CONSTRAINT EMPLEADO_TURNO_FK FOREIGN KEY 
    ( 
     TURNO_id_turno
    ) 
    REFERENCES TURNO 
    ( 
     id_turno
    ) 
;

ALTER TABLE ESTADO_MAQUIv2 
    ADD CONSTRAINT FK__ESTADO_MAQUI FOREIGN KEY 
    ( 
     ESTADO_MAQUI_id_estado
    ) 
    REFERENCES ESTADO_MAQUI 
    ( 
     id_estado
    ) 
;

ALTER TABLE COMUNA 
    ADD CONSTRAINT FK_COMUNA_REGION FOREIGN KEY 
    ( 
     REGION_cod_region
    ) 
    REFERENCES REGION 
    ( 
     cod_region
    ) 
;

ALTER TABLE EMPLEADO 
    ADD CONSTRAINT FK_EMPLEADO_AFP FOREIGN KEY 
    ( 
     AFP_id_afp
    ) 
    REFERENCES AFP 
    ( 
     id_afp
    ) 
;

ALTER TABLE EMPLEADO 
    ADD CONSTRAINT FK_EMPLEADO_EMPLEADO FOREIGN KEY 
    ( 
     EMPLEADO_cod_empleado,
     EMPLEADO_cod_planta,
     EMPLEADO_id_turno,
     EMPLEADO_id_estado
    ) 
    REFERENCES EMPLEADO 
    ( 
     cod_empleado,
     PLANTA_cod_planta,
     TURNO_id_turno,
     ESTADO_ACTIVO_id_estado
    ) 
;

ALTER TABLE EMPLEADO 
    ADD CONSTRAINT FK_EMPLEADO_ESTADO_ACTIVO FOREIGN KEY 
    ( 
     ESTADO_ACTIVO_id_estado
    ) 
    REFERENCES ESTADO_ACTIVO 
    ( 
     id_estado
    ) 
;

ALTER TABLE EMPLEADO 
    ADD CONSTRAINT FK_EMPLEADO_MAQUINA FOREIGN KEY 
    ( 
     MAQUINA_id_maquina
    ) 
    REFERENCES MAQUINA 
    ( 
     id_maquina
    ) 
;

ALTER TABLE EMPLEADO 
    ADD CONSTRAINT FK_EMPLEADO_PLANTA FOREIGN KEY 
    ( 
     PLANTA_cod_planta
    ) 
    REFERENCES PLANTA 
    ( 
     cod_planta
    ) 
;

ALTER TABLE ESTADO_MAQUIv2 
    ADD CONSTRAINT FK_MAQUINA FOREIGN KEY 
    ( 
     MAQUINA_id_maquina
    ) 
    REFERENCES MAQUINA 
    ( 
     id_maquina
    ) 
;

ALTER TABLE OPERARIO 
    ADD CONSTRAINT FK_OPERARIO_CATEGORIA FOREIGN KEY 
    ( 
     CATEGORIA_id_categoria
    ) 
    REFERENCES CATEGORIA 
    ( 
     id_categoria
    ) 
;

ALTER TABLE OPERARIO 
    ADD CONSTRAINT FK_OPERARIO_CERTIFICACION FOREIGN KEY 
    ( 
     CERTIFICACION_id_certificacion
    ) 
    REFERENCES CERTIFICACION 
    ( 
     id_certificacion
    ) 
;

ALTER TABLE OPERARIO 
    ADD CONSTRAINT FK_OPERARIO_EMPLEADO FOREIGN KEY 
    ( 
     cod_empleado,
     cod_planta,
     id_turno,
     id_estado
    ) 
    REFERENCES EMPLEADO 
    ( 
     cod_empleado,
     PLANTA_cod_planta,
     TURNO_id_turno,
     ESTADO_ACTIVO_id_estado
    ) 
;

ALTER TABLE PLANTA 
    ADD CONSTRAINT FK_PLANTA_COMUNA FOREIGN KEY 
    ( 
     COMUNA_cod_comuna
    ) 
    REFERENCES COMUNA 
    ( 
     cod_comuna
    ) 
;

ALTER TABLE TECNICOS_MANT 
    ADD CONSTRAINT FK_TECNICOS_MANT_EMPLEADO FOREIGN KEY 
    ( 
     cod_empleado,
     cod_planta,
     id_turno,
     id_estado
    ) 
    REFERENCES EMPLEADO 
    ( 
     cod_empleado,
     PLANTA_cod_planta,
     TURNO_id_turno,
     ESTADO_ACTIVO_id_estado
    ) 
;

ALTER TABLE TECNICOS_MANT 
    ADD CONSTRAINT FK_TECNICOS_MANT_ESPECIALIDAD FOREIGN KEY 
    ( 
     ESPECIALIDAD_id_especialidad
    ) 
    REFERENCES ESPECIALIDAD 
    ( 
     id_especialidad
    ) 
;

ALTER TABLE INTERMEDIA_TURNO 
    ADD CONSTRAINT Relation_9_TIPO_TURNO_FK FOREIGN KEY 
    ( 
     TIPO_TURNO_id_tipo
    ) 
    REFERENCES TIPO_TURNO 
    ( 
     id_tipo
    ) 
;

ALTER TABLE INTERMEDIA_TURNO 
    ADD CONSTRAINT Relation_9_TURNO_FK FOREIGN KEY 
    ( 
     TURNO_id_turno
    ) 
    REFERENCES TURNO 
    ( 
     id_turno
    ) 
;

--  ERROR: No Discriminator Column found in Arc FKArc_1 - constraint trigger for Arc cannot be generated 

--  ERROR: No Discriminator Column found in Arc FKArc_1 - constraint trigger for Arc cannot be generated

--  ERROR: No Discriminator Column found in Arc Arc_1 - constraint trigger for Arc cannot be generated 

--  ERROR: No Discriminator Column found in Arc Arc_1 - constraint trigger for Arc cannot be generated



-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            18
-- CREATE INDEX                             1
-- ALTER TABLE                             50
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   9
-- WARNINGS                                 0
